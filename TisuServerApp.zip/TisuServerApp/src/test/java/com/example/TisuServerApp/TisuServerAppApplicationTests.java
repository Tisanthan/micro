package com.example.TisuServerApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TisuServerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
